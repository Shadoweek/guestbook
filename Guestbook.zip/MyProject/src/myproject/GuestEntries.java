package myproject;

import java.io.*;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;

@SuppressWarnings("serial")

public class GuestEntries implements Serializable {

	String userName;
	int rating;
	String message;
	Date date = new Date();

	// Constructor with parameters
	public GuestEntries(String userName, int rating, String message) {
		set(userName, rating, message);
	}
	// Default Constructor
	public GuestEntries() {
		set("Default Username", 1, "default message qwertyuiopasdfghjklzxcvbnm");
	}
	// OLD printing method below # just for reference
	/*
	 * public void print() { System.out.println("Enter your username: " + userName);
	 * System.out.println("Enter your date:  \n in format dd/mm/yy" + date);
	 * System.out.println("Enter your message: " + message);
	 * System.out.println("Your message has been added to Guestbook, thank you!"); }
	 * 
	 * // print with a heading - Overloading method public void print(String
	 * heading) { System.out.println(heading); print(); }
	 */ 
	// OLD printing method ends

	// set method for all fields
	public void set(String userName, int rating, String message) {
		setUserName(userName);
		setRating(rating);
		setMessage(message);
	//	setDate(date);
	}

	// set methods for individual fields
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	/*//public void setDate(Date date) {
		this.date = date;
	}*/

	// get methods for individual fields
	public String getUserName() {
		return userName;
	}

	public int getRating() {
		return rating;
	}

	public String getMessage() {
		return message;
	}
	
/*	public Date getDate() {
		return date;
	}*/

	// ask method for user input
	public void ask(String prompt) {
		System.out.println(prompt);
		String userName = Console.askString(">          User name : ");
		setUserName(userName);
		setMessage(Console.askString(">          Message: "));

		try { // implementing a mistype exception catcher
			setRating(Console.askInt(">          How do you rate this guestbook?: "));
			setRating(rating);
		} catch (NumberFormatException e) {
			System.out.println("You must enter a number!");
			setRating(Console.askInt(">          Please put a number from 1 to 10 : "));
			setRating(rating);
		}
		System.out.println("\n				*Your message has been added to Guestbook, thank you!*\n");
	}

	// ask method for userName and date only used in Find
	public String askUserName(String prompt) {
		setUserName(Console.askString("Enter your username to search: "));
		return userName;
	}
				// tried to do date myself but got lost
	/*public Date askUserDate(Date prompt) {
		setDate(Console.askDate("Enter your username to search: "));
		return date;
	}*/

	// toString method
	public String toString() {
		try { // printing the IP address using try method
			System.out.println("\t\t\t\t\t #Machine/IP Address :|" + InetAddress.getLocalHost());
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace(); 
		} // returning print that sums up the input
		return "Rating: " + rating + "\n Submited by: " + userName + "\t\t\tDate: " + date.toString()
				+ "\n\nMessage: \n" + message + "\n\n" + "████████████████████████████████████████████████████████████████████████████████████████████████████████████████";
	}

}