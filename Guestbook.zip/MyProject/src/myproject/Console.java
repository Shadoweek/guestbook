package myproject;

import java.util.Date;
import java.util.Scanner;

/**
 * Develop console class for scanner input Input for String, Integer, Double and
 * Char
 */
public class Console {
	public static Scanner console = new Scanner(System.in);

	public static String askString(String aPrompt) // method for string input
	{
		System.out.print(aPrompt); // aPrompt is a request for string input
		String reply = console.nextLine(); // input held in a variable called reply
		return reply;
	}

	public static int askInt(String aPrompt) // method for integer input
	{
		String reply = askString(aPrompt);
		return Integer.parseInt(reply); // parseInt converts string to integer
	}
			// tried to do date myself
	/*public static long askDate(String aPrompt) 
	{
		String reply = askString(aPrompt);
		return Date.from(Guestbook.content();
	}
	*/
	public static double askDouble(String aPrompt) // method for double input
	{
		String reply = askString(aPrompt);
		return Double.parseDouble(reply); // parseDouble converts string to double
	}

	public static char askChar(String aChar) // method for one character input
	{
		String reply = askString(aChar);
		// Take first character of string and convert to Uppercase
		return Character.toUpperCase(reply.trim().charAt(0));
	}

	// method for one character input for menu options
	public static char askOption(String aMenu) {
		System.out.println(aMenu);
		String reply = askString("\t\t\t\t\t\tEnter option: \n\n");

		if (reply.trim().length() == 0) // checks for null input
			return '\0';
		else
			// Take first character of string and convert to Uppercase
			return Character.toUpperCase(reply.trim().charAt(0));
	}

}