package myproject;
import java.util.Scanner;

public class Menu {
	// Develop menu-driven application
	static Guestbook content = new Guestbook();
	static GuestEntries user;
	static boolean finished = true; // false if not finished
	static boolean finished1 = true; // 
	static String fileName; // data file
	static char menuOption;
	static char findOption;
	static char preMenuOption;
	public static void main(String[] args) throws Exception, NumberFormatException {
		
		
		/* TO DO :  
		 * 	DATE find option
		 * Entry No. by every new entry
		 * Rating score system
		 * Delete entry
		 * ??? Edit ???
		 * */
			

		while (!finished1) // while not finished
		content.open("log.dat");	// opening file containing records in order to make entriesCounter work
		Guestbook.menuLogo(); 	// main menu display using method i've created to make code look more clear
		System.out.println("\n\t\t\t\t\tWelcome to my GuestBook project\n\n "
				+ "\t\t\t\tplease feel free to leave message and test my application"
				+ "\n\t\t\t\tif you need more information check documentation included");
		// Thats pre menu to the guestbook, implementing switch command
		System.out.println("\n\t\t\t\t\tEntries existing in guestbook so far :"+ content.entriesCounter() + "\n");
		preMenuOption	= Console.askOption("\t\t\t\t\t\t(L) Login or (I) Info" + "\n\t\t\t\t\t\tDefault: test/test\n");
		switch (preMenuOption)
		{
				case 'L':	aLogin();	break;
				case 'I':	info();		break;
				default:	System.out.println(" \t\t\t\t\t Please select valid option!");
		}
		start();// starts menu and loads up the data file
		while (!finished) // while not finished
		{
			System.out.println("\t\t\t\t\t____________________________________");
			menuOption = Console.askOption("\t\t\t\t\tSelect from following options \n"
			+ "\t (A)Add new entry \t\t(S)Show existing entries \t (F)Find an entry \t (I) Info \t (Q)Quit ");
			switch (menuOption) {
					case 'A':	addHandler();	break;
					case 'F':	findMenu();	break;
					case 'S':	printHandler();	break;
					case 'Q':	quitHandler();	break;
					case 'I':	info();			break;
					default:	System.out.println(" \t\t\t\t\t Please select valid option!");
			}// end of switch-case
		} // end of while loop
	} // end of main method
		// upgraded version of Find menu
	public static void findMenu() {
		findOption = Console.askOption("\t\t\tFind by:\n"
				+ "\t\t\t(U)By Username	\t(D)By Date");
		switch (findOption) {
		//case 'D':	findDateHandler();	break;
		case 'U':	findHandler();	break;
		default:	System.out.println(" \t\t\t\t\t Please select valid option!");
		}
	}
	// tried to do date myself
/*	public static void dateHandler() {
		user = new GuestEntries();
		Date newDate = user.getDate("\nEnter username to find entry: ");
		// Checking if user is arleady in entries
		if (content.findDate(date) != null)
			System.out.println(
					"\n\t\t\t\t\t\t\t***SUCCESS***\n\n____________________________\n" + content.findUser(userUserName));
		else
			System.out.println("Error: user not found \n");
	}*/
	public static void start() {
		try {
			content.open("log.dat");// pre-defined name
			System.out.println("\t\t\t\t\t____________________________________");
			System.out.println("\t\t\t\t\tGuestbook file is opened, the entries will be saved.");
		} catch (Exception e) {
			System.out.println("\t\t\t\t\t*Guestbook file is not created yet!*");
			System.out.println("\t\t\t\t\t____________________________________");
		}
	}
	public static void addHandler() {
		user = new GuestEntries();
		user.ask("\t\t\tEnter your username: ");
		if (content.findUser(user.getUserName()) != null) {
			System.out.println("Entry from that username arleady exists!");
		} else { 
			content.add(user);
		}
	}
	public static void findHandler() {
		user = new GuestEntries();
		String userUserName = user.askUserName("\nEnter username to find entry: ");
		// Checking if user is arleady in entries
		if (content.findUser(userUserName) != null)
			System.out.println(
					"\n\t\t\t\t\t\t\t***SUCCESS***\n\n____________________________\n" + content.findUser(userUserName));
		else
			System.out.println("Error: user not found \n");
	}
	public static void printHandler() {
		content.print("\n\nEntries existing in guestbook :" + content.entriesCounter());
	}

	public static void quitHandler() throws Exception {
		finished = true; // finished
		System.out.println("Saving entries to the log file");
		System.out.println("Thank you for using my application!");
		System.out.println(
				"\t\t\t\t  ██████ ▓█████ ▓█████    ▓██   ██▓ ▒█████   █    ██ \r\n" + 
				"\t\t\t\t▒██    ▒ ▓█   ▀ ▓█   ▀     ▒██  ██▒▒██▒  ██▒ ██  ▓██▒\r\n" + 
				"\t\t\t\t░ ▓██▄   ▒███   ▒███        ▒██ ██░▒██░  ██▒▓██  ▒██░\r\n" + 
				"\t\t\t\t  ▒   ██▒▒▓█  ▄ ▒▓█  ▄      ░ ▐██▓░▒██   ██░▓▓█  ░██░\r\n" + 
				"\t\t\t\t▒██████▒▒░▒████▒░▒████▒     ░ ██▒▓░░ ████▓▒░▒▒█████▓ \r\n" + 
				"\t\t\t\t▒ ▒▓▒ ▒ ░░░ ▒░ ░░░ ▒░ ░      ██▒▒▒ ░ ▒░▒░▒░ ░▒▓▒ ▒ ▒ \r\n" + 
				"\t\t\t\t░ ░▒  ░ ░ ░ ░  ░ ░ ░  ░    ▓██ ░▒░   ░ ▒ ▒░ ░░▒░ ░ ░ \r\n" + 
				"\t\t\t\t░  ░  ░     ░      ░       ▒ ▒ ░░  ░ ░ ░ ▒   ░░░ ░ ░ \r\n" + 
				"\t\t\t\t      ░     ░  ░   ░  ░    ░ ░         ░ ░     ░     \r\n" + 
				"\t\t\t\t                           ░ ░                       \r\n" + 
				"\t\t\t\t");
		System.out.println( 
				"\t\t\t\t __    __              __       __              __       \r\n" + 
				"\t\t\t\t/  |  /  |            /  |  _  /  |            /  |      \r\n" + 
				"\t\t\t\t$$ |  $$ |            $$ | / \\ $$ |            $$ |     \r\n" + 
				"\t\t\t\t$$ |  $$ |            $$ |/$  \\$$ |            $$ |     \r\n" + 
				"\t\t\t\t$$ |  $$ |            $$ /$$$  $$ |            $$ |      \r\n" + 
				"\t\t\t\t$$ |  $$ |            $$ $$/$$ $$ |            $$ |      \r\n" + 
				"\t\t\t\t$$ \\__$$ |            $$$$/  $$$$ |            $$ |_____ \r\n" + 
				"\t\t\t\t$$    $$/             $$$/    $$$ |            $$       |\r\n" + 
				"\t\t\t\t $$$$$$/niversity     $$/      $$/est          $$$$$$$$/ondon\r\n");
										content.save("log.dat"); // saving to file
	}

	public static void info() {
		System.out.println("\t\t\t_______oBBBBB8o______oBBBBBBB \r\n"
				+ "\t\t\t_____o8BBBBBBBBBBB__BBBBBBBBB8________o88o, \r\n"
				+ "\t\t\t___o8BBBBBB**8BBBB__BBBBBBBBBB_____oBBBBBBBo, \r\n"
				+ "\t\t\t__oBBBBBBB*___***___BBBBBBBBBB_____BBBBBBBBBBo, \r\n"
				+ "\t\t\t_8BBBBBBBBBBooooo___*BBBBBBB8______*BB*_8BBBBBBo, \r\n"
				+ "\t\t\t_8BBBBBBBBBBBBBBBB8ooBBBBBBB8___________8BBBBBBB8, \r\n"
				+ "\t\t\t__*BBBBBBBBBBBBBBBBBBBBBBBBBB8_o88BB88BBBBBBBBBBBB, \r\n"
				+ "\t\t\t____*BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB8, \r\n"
				+ "\t\t\t______**8BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB*, \r\n"
				+ "\t\t\t___________*BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB8*, \r\n"
				+ "\t\t\t____________*BBBBBBBBBBBBBBBBBBBBBBBB8888**, \r\n"
				+ "\t\t\t_____________BBBBBBBBBBBBBBBBBBBBBBB*, \r\n"
				+ "\t\t\t_____________*BBBBBBBBBBBBBBBBBBBBB*, \r\n" + "\t\t\t______________*BBBBBBBBBBBBBBBBBB8, \r\n"
				+ "\t\t\t_______________*BBBBBBBBBBBBBBBB*, \r\n" + "\t\t\t________________8BBBBBBBBBBBBBBB8, \r\n"
				+ "\t\t\t_________________8BBBBBBBBBBBBBBBo, \r\n" + "\t\t\t__________________BBBBBBBBBBBBBBB8, \r\n"
				+ "\t\t\t__________________BBBBBBBBBBBBBBBB, \r\n" + "\t\t\t__________________8BBBBBBBBBBBBBBB8, \r\n"
				+ "\t\t\t__________________*BBBBBBBBBBBBBBBB, \r\n" + "\t\t\t__________________8BBBBBBBBBBBBBBBB8, \r\n"
				+ "\t\t\t_________________oBBBBBBBBBBBBBBBBBB, \r\n"
				+ "\t\t\t________________oBBBBBBBBBBBBBBBBBBB, \r\n"
				+ "\t\t\t________________BBBBBBBBBBBBBBBBBBBB, \r\n"
				+ "\t\t\t_______________8BBBBBBBBBBBBBBBBBBB8, \r\n"
				+ "\t\t\t______________oBBBBBBBBB88BBBBBBBBB8, \r\n"
				+ "\t\t\t______________8BBBBBBBBB*8BBBBBBBBB*, \r\n" + "\t\t\t______________BBBBBBBBB*_BBBBBBBBB8, \r\n"
				+ "\t\t\t______________BBBBBBBB8_oBBBBBBBBB*, \r\n" + "\t\t\t______________8BBBBBBB__oBBBBBBBB*, \r\n"
				+ "\t\t\t______________BBBBBBB*__8BBBBBBB*, \r\n" + "\t\t\t_____________8BBBBBB*___BBBBBBB*, \r\n"
				+ "\t\t\t____________8BBBBBB8___oBBBBBB8, \r\n" + "\t\t\t___________8BBBBBB8____8BBBBBB*, \r\n"
				+ "\t\t\t__________oBBBBBB8____BBBBBBB8, \r\n" + "\t\t\t__________BBBBBBB8___BBBBBBBB*, \r\n"
				+ "\t\t\t_________oBBBBBBB8___BBBBBBBB, \r\n" + "\t\t\t_________8BBBBBB8____BBBBBBB*, \r\n"
				+ "\t\t\t_________BBBBBB*_____8BBBBB*, \r\n" + "\t\t\t________oBBBB8_______BBBBB*, \r\n"
				+ "\t\t\t________oBBB8________BBBB*, \r\n" + "\t\t\t______8BBBB*_______*BBBBBBBB8o, \r\n"
				+ "\t\t\t______BBBBB*____________*88BBBo\r\n" + "\t\t\t");
			
		System.out.println(
				"\t\tThis guestbook was created by Patryk Michal Zajdel( 21363052 ) and is still under development"
						+ "\t\t\n \t\tPlease share any tips or improvement that could be implemented "
						+ "on 21363052@student.uwl.ac.uk");	
		System.out.println("\t\t\t\tCurrent version of application:  *V.01*");
		} // end of info

	public static void aLogin() 
	{	
		String Username;
		String Password;
			// thats the field to define what password it going to use
		Password = "test"; 
		Username = "test";

		Scanner input1 = new Scanner(System.in);
		System.out.println("\t\t\t\t\tEnter Username : ");
		String username = input1.next();

		Scanner input2 = new Scanner(System.in);
		System.out.println("\t\t\t\t\tEnter Password : ");
		String password = input2.next();

		if (username.equals(Username) && password.equals(Password)) {
			System.out.println(""
					+ "\t █████╗ ██████╗███████████████████████████╗     ██████╗██████╗ █████╗███╗   ███████████████████████╗ \r\n"
					+ "\t██╔══████╔════██╔════██╔════██╔════██╔════╝    ██╔════╝██╔══████╔══██████╗  ██╚══██╔══██╔════██╔══██╗\r\n"
					+ "\t█████████║    ██║    █████╗ ██████████████╗    ██║  █████████╔█████████╔██╗ ██║  ██║  █████╗ ██║  ██║\r\n"
					+ "\t██╔══████║    ██║    ██╔══╝ ╚════██╚════██║    ██║   ████╔══████╔══████║╚██╗██║  ██║  ██╔══╝ ██║  ██║\r\n"
					+ "\t██║  ██╚██████╚███████████████████████████║    ╚██████╔██║  ████║  ████║ ╚████║  ██║  █████████████╔╝\r\n"
					+ "\t╚═╝  ╚═╝╚═════╝╚═════╚══════╚══════╚══════╝     ╚═════╝╚═╝  ╚═╚═╝  ╚═╚═╝  ╚═══╝  ╚═╝  ╚══════╚═════╝ \r\n");
				finished = false;
		}
		else if (username.equals(Username)) {
			System.out.println("Invalid Password!");
			System.out.println("Access Denied!");
		} else if (password.equals(Password)) {
			System.out.println("Invalid Username!");
			System.out.println("Access Denied!");
		} else {
			System.out.println("Invalid Username & Password!");
			System.out.println("Access Denied!");
		}
	}// end of aLogin
}	// end of program
