package myproject;

import java.io.*;
//import ArrayList class from java.util library
import java.util.ArrayList;

public class Guestbook
{
	// Properties: ArrayList to store contents of GuestEntry class
	ArrayList<GuestEntries> contents;// Collection of contents
	ArrayList<String> user;// Array containing guestbook user entries
	  // Constructor
	public Guestbook()
	{
		// new container to hold contents from Item class
		contents = new ArrayList<GuestEntries>(); 
		user = new ArrayList<String>();
		
	}

	// method to return size of ArrayList
	public int getSize()
	{
		// return total number of contents contained in ArrayList
		return contents.size(); 
	}
	
	public int entriesCounter()
	{
			return contents.size();
	}
	
	@SuppressWarnings("resource")
	public void save(String fileName) throws Exception, RuntimeException
	{
		    FileOutputStream outFile;
		   try // to open file
		    {
		      outFile = new FileOutputStream(fileName);
		    }
		    catch (IOException io)
		    {
		      throw new Exception("Cannot create " + fileName);
		    }
		    ObjectOutputStream dataFile;
		 try  // to write file
		    {
		      dataFile = new ObjectOutputStream(outFile);
		      dataFile.writeObject(user);
		      dataFile.writeObject(contents);
		    }
		    catch (IOException io)
		    {
		      throw new Exception("Cannot write to " + fileName);
		    }
		    try // to close file
		    {
		      dataFile.close();
		    }
		    catch (IOException io)
		    {
		      throw new Exception("Cannot close " + fileName);
		    }
		  }

		@SuppressWarnings({ "resource", "unchecked" })
	public void open(String fileName) throws Exception
		{
		    FileInputStream inFile;
		  try // to open file
		    {
		      inFile = new FileInputStream(fileName);
		   }
		    catch (FileNotFoundException e)
		    {
		      throw new Exception("File " + fileName + " not found.");
		    }

		    ObjectInputStream dataFile;
		    try // to read file
		    {
		      dataFile = new ObjectInputStream(inFile);
		      user = (ArrayList<String>)dataFile.readObject();
		      contents = (ArrayList<GuestEntries>)dataFile.readObject();
		    }
		    catch (IOException e)
		    {
		      throw new Exception("Error reading from " + fileName);
		    }
		    catch (ClassNotFoundException e)
		    {
		      throw new Exception("Error reading from " + fileName);
		    }
		    try
		    {
		    // to close file
		    dataFile.close();
		    }
		    catch (IOException e)
		    {
		      throw new Exception("Cannot close " + fileName);
		    }
		  } // end open
	
	
	public void add(GuestEntries anItem)
	{
		contents.add(anItem); // add anItem to contents
		user.add(anItem.getUserName()); // get Username and add to user
		
	}
	// find method
	public GuestEntries findUser(String userName)
	{
		int index = user.indexOf(userName);
		if (index == -1) // if user not found
			return null;
		else
			return contents.get(index);
	}
		// tried to do find by date
	/*public GuestEntries findDate(Date date)
	{
		int index = user.indexOf(date);
		if (index == -1) // if user not found
			return null;
		else
			return contents.get(index);
			}*/
	static void menuLogo() 
	{
		System.out.println("\r\n" + 
				"\t\t\t  _____                 _   ____              _             ___  __ \r\n" + 
				"\t\t\t / ____|               | | |  _ \\            | |           / _ \\/_ |\r\n" + 
				"\t\t\t| |  __ _   _  ___  ___| |_| |_) | ___   ___ | | __ __   _| | | || |\r\n" + 
				"\t\t\t| | |_ | | | |/ _ \\/ __| __|  _ < / _ \\ / _ \\| |/ / \\ \\ / / | | || |\r\n" + 
				"\t\t\t| |__| | |_| |  __/\\__ \\ |_| |_) | (_) | (_) |   <   \\ V /| |_| || |\r\n" + 
				"\t\t\t \\_____|\\__,_|\\___||___/\\__|____/ \\___/ \\___/|_|\\_\\   \\_(_)\\___/ |_|\r\n\n\n");
		
	}
	// print each item from the contents container class
	public void print(String heading)
	{
		System.out.println(heading);
		for (int i=0; i < contents.size(); i++) // for each item in ArrayList
			System.out.println( contents.get(i) ); // get it and print it
	}
}

